﻿// See https://aka.ms/new-console-template for more information
using UnitTestWithGithubActionDemo.Models;

Console.WriteLine("Simple Coverage Demo");
Console.WriteLine($"2 + 3 = {Calculator.Add(2, 3)}");
